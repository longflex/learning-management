<?php $__env->startSection('body'); ?>
    <body class="main">
        <?php echo $__env->yieldContent('substyle'); ?>
        <?php echo $__env->yieldContent('content'); ?>
        
        

        <!-- BEGIN: JS Assets-->
        <!-- <script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBG7gNHAhDzgYmq4-EHvM4bqW1DNj2UCuk&libraries=places"></script> -->
        <script src="<?php echo e(mix('dist/js/app.js')); ?>"></script>
        <!-- END: JS Assets-->

        <?php echo $__env->yieldContent('script'); ?>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\nigeria\Midone Laravel\Laravel Version\Icewall v2.0.1\Source\resources\views////layout/main.blade.php ENDPATH**/ ?>